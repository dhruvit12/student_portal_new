
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
  <!-- Navbar -->
  <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
    <div class="container-fluid py-1 px-3">

      <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
        <ul class="navbar-nav  justify-content-end">
          <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
            <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
              <div class="sidenav-toggler-inner">
                <i class="sidenav-toggler-line"></i>
                <i class="sidenav-toggler-line"></i> 
                <i class="sidenav-toggler-line"></i>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- End Navbar -->
  <div class="container-fluid py-4">
    <div class="row mb-4">
      <!-- First Header start -->
      <div class="col-xl-9 col-sm-9 mb-xl-0 mb-4 offset-1">
        <div class="card course_header_new">
          <div class="row">
            <div class="col"></div>
            <div class="col">  <a href="<?php echo base_url()?>course">Recording</a></div>

            <div class="col" style="color: rgb(90, 66, 66);border-bottom: cadetblue;border: 18px;border-bottom: 0px solid #E46F0A;border-width: 4px;"> <a href="<?php echo base_url()?>project" id="project">Project</a></div>
            <div class="col"> <a href="<?php echo base_url()?>assignment" id="assignment">Assignment</a></div>
            <div class="col"> <a href="<?php echo base_url()?>case_study" id="case study">Case<span style="color: #ffffff;">_</span>Study</a></div>
            <div class="col">   <a href="<?php echo base_url()?>quiz" id="quiz">Quiz</a></div>
            <div class="col"></div>
          </div>
        </div>
        <!-- First Header end -->
      </div>
      
      <div class="row mb-4">
        <span style="margin-left: 40px;color: #535252;margin-top: 30px;margin-bottom: 30px;font-family: 'Poppins' !important;font-size: 60px !important;font-weight: bold;">
          Project
        </span>



        <!-- ACTIVITY -->
      </div>
      <div class="row">


        <div class="col-md-12">
          <div class="jumbotron" id="project_session">
            <div class="row">
              <div class="col-md-4" style="
              float: left !important;
              height: 251px;
              ">
              <img src="<?php echo base_url();?>assets/images/university/python-1.png" id="icon"style="display: flex;width: auto;height: auto;max-height: 268px;margin-top: -7px;float: left !important;margin-left: -8px;" alt="CoolBrand">
            </div>

            <div class="col-md-8 mt-6" style="
            display: grid;
            padding:0;
            margin-left: initial;
            padding-left: 80px;
            padding-right: 30px;
            ">
            <span style="color: #585252;font-size: 30px;margin-bottom: -7px;margin-top: -37px;">Human Resource Attrition</span>
            <span style="color: #585252;font-size: 18px;padding-bottom: 0;margin-bottom: -26px;margin-top: 5px;line-height: normal;">To retain employees, the organization must understand what makes a team member leave a 
              position, what makes them want to stay and invest in the future of the business and what types 
              of issues will create dissatisfaction.
            </span>
            <span style="color:#949393;font-size: 14px;padding-top: 27px;line-height: normal;" id="sub-contect">Starts at: Feb 25, 11:00 AM          </span>
            <span style="color:#949393;font-size: 15px;padding-bottom: 11px;"id="sub-contect">November 30        </span>
            <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" >
             
              <button id="project_course_button">Download Case Study</button>
            </span>
          </div>
        </div>
      </div>
    </div>


        <div class="col-md-12 mt-4">
          <div class="jumbotron" id="project_session">
            <div class="row">
              <div class="col-md-4" style="
              float: left !important;
              height: 251px;
              ">
              <img src="<?php echo base_url();?>assets/images/university/predictive.png" id="icon"style="display: flex;width: auto;height: auto;max-height: 268px;margin-top: -7px;float: left !important;margin-left: -8px;" alt="CoolBrand">
            </div>

            <div class="col-md-8 mt-6" style="
            display: grid;
            padding:0;
            margin-left: initial;
            padding-left: 80px;
            padding-right: 30px;
            ">
            <span style="color: #585252;font-size: 30px;margin-bottom: -7px;margin-top: -37px;">Predictive Analytics Using External Data</span>
            <span style="color: #585252;font-size: 18px;padding-bottom: 0;margin-bottom: -26px;margin-top: 5px;line-height: normal;">The ability to integrate data from sources outside the enterprise is crucial to many businesses. 
Analysis of external data is tedious and time consuming if it is not easily handled by an augmented
 analytics solution.
            </span>
            <span style="color:#949393;font-size: 14px;padding-top: 27px;line-height: normal;" id="sub-contect">Starts at: Feb 25, 11:00 AM          </span>
            <span style="color:#949393;font-size: 15px;padding-bottom: 11px;"id="sub-contect">November 30        </span>
            <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" >
             
              <button id="project_course_button">Download Case Study</button>
            </span>
          </div>
        </div>
      </div>
    </div>
            <div class="col-md-12 mt-4">
          <div class="jumbotron" id="project_session">
            <div class="row">
              <div class="col-md-4" style="
              float: left !important;
              height: 251px;
              ">
              <img src="<?php echo base_url();?>assets/images/university/online-target-marketing-small.png" id="icon"style="display: flex;width: auto;height: auto;max-height: 268px;margin-top: -7px;float: left !important;margin-left: -8px;" alt="CoolBrand">
            </div>

            <div class="col-md-8 mt-6" style="
            display: grid;
            padding:0;
            margin-left: initial;
            padding-left: 80px;
            padding-right: 30px;
            ">
            <span style="color: #585252;font-size: 30px;margin-bottom: -7px;margin-top: -37px;">Online Target Marketing</span>
            <span style="color: #585252;font-size: 18px;padding-bottom: 0;margin-bottom: -26px;margin-top: 5px;line-height: normal;">In order to optimize available marketing funds and resources, the enterprise must understand what 
works and what does not work, where to put its messaging and the ideal profile and demographic for
its targeted customers
            </span>
            <span style="color:#949393;font-size: 14px;padding-top: 27px;line-height: normal;" id="sub-contect">Starts at: Feb 25, 11:00 AM          </span>
            <span style="color:#949393;font-size: 15px;padding-bottom: 11px;"id="sub-contect">November 30        </span>
            <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" >
             
              <button id="project_course_button">Download Case Study</button>
            </span>
          </div>
        </div>
      </div>
    </div>
            


</div>





</div>
</main>
