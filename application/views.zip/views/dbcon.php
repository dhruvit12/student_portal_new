<?php
//$con = mysqli_connect('localhost', 'jvfdbhhs_anzarkhan-com', 'iS3!yRffH2r4A5E', 'jvfdbhhs_fingertips_portal');
   $con = mysqli_connect('localhost', 'root', '', 'jvfdbhhs_fingertips_portal');
  if (!$con) {
    echo "Connection Failed!";
  }
ini_set('display_errors', 0);
  ?>