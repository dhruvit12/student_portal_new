
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
  <!-- Navbar -->
  <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
    <div class="container-fluid py-1 px-3">

      <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
        <ul class="navbar-nav  justify-content-end">
          <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
            <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
              <div class="sidenav-toggler-inner">
                <i class="sidenav-toggler-line"></i>
                <i class="sidenav-toggler-line"></i> 
                <i class="sidenav-toggler-line"></i>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  
  <!-- End Navbar -->
  <div class="container-fluid py-4">
    <div class="row mb-4">
      <!-- First Header start -->
      <div class="col-xl-9 col-sm-9 mb-xl-0 mb-4 offset-1">
        <div class="card course_header_new">
          <div class="row">
            <div class="col"></div>
            <div class="col"style="color: rgb(90, 66, 66);border-bottom: cadetblue;border: 18px;border-bottom: 0px solid #E46F0A;border-width: 4px;">  <a href="<?php echo base_url()?>course">Recording</a></div>

            <div class="col"> <a href="<?php echo base_url()?>project" id="project">Project</a></div>
            <div class="col"> <a href="<?php echo base_url()?>assignment" id="assignment">Assignment</a></div>
            <div class="col"> <a href="<?php echo base_url()?>case_study" id="case study">Case<span style="color: #ffffff;">_</span>Study</a></div>
            <div class="col">   <a href="<?php echo base_url()?>quiz" id="quiz">Quiz</a></div>
            <div class="col"></div>
          </div>
        </div>
        <!-- First Header end -->
      </div>
      <script>
 document.getElementById('menu_course').classList.add("menu-active");
 document.getElementById('sidebar_icon_2').style.fill='#E46F0E';

</script>
      <div class="row mb-4">
        <span style="margin-left: 40px;color: #535252;margin-top: 30px;margin-bottom: 30px;font-family: 'Poppins' !important;font-size: 60px !important;font-weight: bold;">
          Python Sessions
        </span>



        <!-- ACTIVITY -->
      </div>
      <div class="row">


        <div class="col-md-12">
          <div class="jumbotron" id="course_session">
            <div class="row">
              <div class="col-md-1">
               <span class="nav-item" data-toggle="modal" data-target="#video_list" onclick="prepareVideoListModal(
               516                  )">
               <img src="<?php echo base_url();?>assets/images/student_portal_icon/play.png" id="icon" style="height: auto;display: flex;width: auto;height: auto;padding: 24px !important;" alt="CoolBrand">

             </span>
           </div>

           <div class="col-md-5 mt-3" style="
           display: grid;
           margin-left: initial;
           padding-left: 51px;
           ">
           <span style="color: #858585;font-size: 30px;margin-bottom: -20px;">Python session one </span>
           <span style="color:#949393;font-size: 19px;padding-bottom: 0;margin-bottom: -26px;margin-top: 0px;" id="sub-contect">Course: Python for Data Science</span>
           <span style="color:#949393;font-size: 19px;" id="sub-contect">Starts at: Feb 25, 11:00 AM            </span>
         </div>
         <div class="col-md-6" style="display: flex;align-items: center;">

          <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" onclick="prepareReadingMaterialListModal(
          'Statistics Fundamentals Module III',82                                                   )">
          &nbsp;&nbsp;&nbsp;&nbsp; 
          <button id="course_button">Knowledge check</button>&nbsp;&nbsp;
        </span>
        <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" onclick="prepareReadingMaterialListModal(
        'Statistics Fundamentals Module III',82                                                   )">
        &nbsp;&nbsp;&nbsp;&nbsp; 
        <button id="course_button">Reading Material </button>&nbsp;&nbsp;
        </span> <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" onclick="prepareReadingMaterialListModal(
        'Statistics Fundamentals Module III',82                                                   )">
        &nbsp;&nbsp;&nbsp;&nbsp; 
        <button id="course_button">Reading Material </button>&nbsp;&nbsp;
      </span>
      <!-- <button id="course_button">Reading Material </button>&nbsp; -->
    </div>
  </div>
</div>
</div>

  <?php 
  require_once 'dbcon.php';
      if(!empty($session_list)){
                        foreach($session_list as $session_data)
                        {

                    ?>
                      <?php
                  $query100 = "SELECT * FROM `offline_session_log` WHERE `session_id` = $session_data->id;";
                  $runfetch100 = mysqli_query($con, $query100);
                  $noofrow100 = mysqli_num_rows($runfetch100);
                  $indexnumber100 = 1;
                  if ($noofrow100 >0 && $runfetch100 == TRUE) { 
                  while ($data100 = mysqli_fetch_assoc($runfetch100)) { 
                      // use of explode 
                      $string1 = $data100['recording_files']; 
                      $str_arr1 = explode (",", $string1);  
                      $no_of_videos =  sizeof($str_arr1);
                      $video_comment = $data100['video_comment'];
                   }
                  }
                  ?>
               <?php 
               if($no_of_videos == 1){

                ?>
                <div class="col-md-12 mt-4">
                  <div class="jumbotron" id="course_session">
                    <div class="row">
                      <div class="col-md-1">
                       <span class="nav-item" data-toggle="modal" data-target="#video_list"  onclick= "prepareNoVideoReason(
                        <?php                                                                  
                        echo "'".$video_comment."'";
                        ?>
                        )"
                        >
                        <img src="<?php echo base_url();?>assets/images/student_portal_icon/play.png" id="icon" style="height: auto;display: flex;width: auto;height: auto;padding: 24px !important;" alt="CoolBrand">

                      </span>
                    </div>

                    <div class="col-md-5 mt-3" style="
                    display: grid;
                    margin-left: initial;
                    padding-left: 51px;
                    ">
                    <span style="color: #858585;font-size: 30px;margin-bottom: -20px;"><?php print_r($session_data->session_name);?> </span>
                    <span style="color:#949393;font-size: 19px;padding-bottom: 0;margin-bottom: -26px;margin-top: 0px;" id="sub-contect">Course:<?php print_r(ucwords($course_name[0]->name));?></span>
                    <span style="color:#949393;font-size: 19px;" id="sub-contect">Starts at: Feb 25, 11:00 AM            </span>
                  </div>
                  <div class="col-md-6" style="display: flex;align-items: center;">

                    <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" onclick="prepareReadingMaterialListModal(
                    'Statistics Fundamentals Module III',82                                                   )">
                    &nbsp;&nbsp;&nbsp;&nbsp; 
                    <button id="course_button">Knowledge check</button>&nbsp;&nbsp;
                  </span>
                  <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" onclick="prepareReadingMaterialListModal(
                  'Statistics Fundamentals Module III',82                                                   )">
                  &nbsp;&nbsp;&nbsp;&nbsp; 
                  <button id="course_button">Reading Material </button>&nbsp;&nbsp;
                  </span> <span class="nav-item" style="cursor:pointer;" data-toggle="modal" data-target="#reading_material_list" onclick="prepareReadingMaterialListModal(
                  'Statistics Fundamentals Module III',82                                                   )">
                  &nbsp;&nbsp;&nbsp;&nbsp; 
                  <button id="course_button">Reading Material </button>&nbsp;&nbsp;
                </span>
                <!-- <button id="course_button">Reading Material </button>&nbsp; -->
              </div>
            </div>
          </div>
        </div>   

      <?php } } }?>


</div>





</div>
<div class="modal fade" id="reading_material_list" >
                        <div class="modal-dialog modal-md modal-dialog-centered"  >
                           <div class="modal-content">
                              <div class="modal-header border-0" >
                                 <h4 class="modal-title">Reading Materials</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <div class="modal-body text-center " id="readingMaterialListModalId" style="" >
                              </div>
                              <div class="modal-footer border-0" >
                                 <button type="button" class="btn btn-default" style="background-color:#26266C;color:#ffffff" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
<div class="modal fade" id="video_list">
   <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">
         <!-- Modal Header -->
         <div class="modal-header">
            <h4 class="modal-title">Class Recordings</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
         </div>
         <!-- Modal body -->
         <div class="modal-body text-center" id="videoListModalId">
         </div>
         <!-- Modal footer -->
         <div class="modal-footer">
            <button type="button" class="btn btn-default" style="background-color:#26266C;color:#ffffff" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="no_video_reason" style="z-index:999999">
   <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">
         <!-- Modal Header -->
         <div class="modal-header">
            <h4 class="modal-title">Class Recordings</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
         </div>
         <!-- Modal body -->
         <div class="modal-body text-center" id="noVideoReasonModalId" style="overflow-x:auto;">
         </div>
         <!-- Modal footer -->
         <div class="modal-footer">
            <button type="button" class="btn btn-default" style="background-color:#26266C;color:#ffffff" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>
</main>
<script src="<?php echo base_url()?>assets/js/student-dashboard-modal-create.js"></script>
<script src="<?php echo base_url()?>assets/js/chart/chartist/chartist.js"></script>
<script src="<?php echo base_url()?>assets/js/jquery-3.2.1.min.js"></script>